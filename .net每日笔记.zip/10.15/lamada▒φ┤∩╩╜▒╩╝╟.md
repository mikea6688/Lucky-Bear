# Lamada表达式

> lamada是一个匿名函数，本质上是个“语法糖”

## Lamada 6大基础语法

## 四大内置核心函数式接口

## 方法运用,构造器引用

## 强大的stream

## stream的并行流和串行流

## forkJoin和Stream并行流的关系

